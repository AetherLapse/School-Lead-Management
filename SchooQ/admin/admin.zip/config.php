<?php
// Fill Credentials Here
// Database credentials
$servername = '';
$username = '';
$password = '';
$dbname = '';
?>